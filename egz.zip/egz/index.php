<?php
$conn = mysqli_connect('localhost','root','','sklep');

// sk1
$zap1 = "SELECT towary.nazwa, towary.cena FROM towary LIMIT 4;";
$res1 = mysqli_query($conn, $zap1);

// sk2
if(isset($_POST['oblicz'])){
$zap2 = "SELECT towary.cena FROM towary WHERE towary.nazwa = $_POST[art];";
$res2 = mysqli_query($conn, $zap2);
}

?>
<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Hurtownia szkolna</title>
    <link rel="stylesheet" href="styl.css">
</head>
<body>
<main>
        <header>
            <h1>Hurtownia z najlepszymi cenami</h1>
        </header>

        <section class = "left">
            <h2>Nazse ceny</h2>
            <table>  
                <?php 
                while($w = mysqli_fetch_row($res1)){
                echo "
                <tr>
                    <td>$w[0]</td>
                    <td>$w[1]</td>
                </tr> ";
                }
                    ?>
            </table>
        </section>

        <section class = "centr">
            <h2>Koszt zakupów</h2>
            <form action="" method="post">
                <label for="art">Wybierz artykuł:</label>
                <select name="art">
                    <option value="Zeszyt 60 kartek">Zeszyt 60 kartek</option>
                    <option value="Zaszyt 32 kartki">Zaszyt 32 kartki</option>
                    <option value="Cyrkiel">Cyrkiel</option>
                    <option value="Linijka 30cm">Linijka 30cm</option>
                </select>
                <label for="liczba">Liczba sztuk:</label>
                <input type="number" name="liczba">
                <input type="submit" name="oblicz" value="oblicz">
                sk2
            </form>
            <div>
                <?php
                
                ?>
            </div>
        </section>

        <section class ="prawy">
            <h2>Kontakt</h2>
            <img src="zakupy.png" alt="hurtownia">
            <p>e-mail: <a href="hurt@poczta2.pl">hurt@poczta2.pl</a></p> 
</section>
</main>
        <footer>
            Witryne wykonał: 15
        </footer>
</body>
</html>

<?php
mysqli_close($conn);
?>